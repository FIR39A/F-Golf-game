﻿open System
open System.Drawing
open System.Media
open System.Windows.Forms

// Típusok
type Ball =
    { mutable Position: PointF
      mutable Velocity: PointF
      Radius: float32 }

type Obstacle = RectangleF

type Level =
    { Name: string
      Start: PointF
      Hole: PointF
      Obstacles: Obstacle list }

// Pályák
let levels = [
    {
        Name = "1. pálya"
        Start = PointF(100.f, 300.f)
        Hole = PointF(700.f, 100.f)
        Obstacles = [
            RectangleF(0.f, 0.f, 800.f, 40.f)
            RectangleF(0.f, 560.f, 800.f, 40.f)
            RectangleF(300.f, 40.f, 40.f, 200.f)
            RectangleF(300.f, 360.f, 40.f, 200.f)
            RectangleF(640.f, 40.f, 40.f, 100.f)
        ]
    }
    {
        Name = "2. pálya"
        Start = PointF(100.f, 500.f)
        Hole = PointF(700.f, 100.f)
        Obstacles = [
            RectangleF(0.f, 0.f, 800.f, 40.f)
            RectangleF(0.f, 560.f, 800.f, 40.f)
            RectangleF(200.f, 100.f, 20.f, 400.f)
            RectangleF(400.f, 100.f, 20.f, 400.f)
        ]
    }
    {
        Name = "3. pálya"
        Start = PointF(400.f, 500.f)
        Hole = PointF(400.f, 100.f)
        Obstacles = [
            RectangleF(0.f, 0.f, 800.f, 40.f)
            RectangleF(0.f, 560.f, 800.f, 40.f)
            RectangleF(300.f, 150.f, 200.f, 40.f)
            RectangleF(300.f, 400.f, 200.f, 40.f)
            RectangleF(200.f, 250.f, 20.f, 100.f)
            RectangleF(580.f, 250.f, 20.f, 100.f)
        ]
    }
    {
        Name = "4. pálya"
        Start = PointF(100.f, 100.f)
        Hole = PointF(700.f, 500.f)
        Obstacles = [
            RectangleF(0.f, 0.f, 800.f, 40.f)
            RectangleF(0.f, 560.f, 800.f, 40.f)
            RectangleF(200.f, 100.f, 20.f, 300.f)
            RectangleF(580.f, 200.f, 20.f, 100.f) // felső akadály
            RectangleF(580.f, 360.f, 20.f, 140.f) // alsó akadály
            RectangleF(300.f, 380.f, 200.f, 20.f)
        ]
    }
    {
        Name = "5. pálya"
        Start = PointF(400.f, 500.f)
        Hole = PointF(400.f, 100.f)
        Obstacles = [
            RectangleF(0.f, 0.f, 800.f, 40.f)
            RectangleF(0.f, 560.f, 800.f, 40.f)
            RectangleF(200.f, 150.f, 400.f, 20.f)
            RectangleF(200.f, 430.f, 400.f, 20.f)
            RectangleF(200.f, 150.f, 20.f, 120.f)
            RectangleF(200.f, 330.f, 20.f, 120.f)
            RectangleF(580.f, 150.f, 20.f, 120.f)
            RectangleF(580.f, 330.f, 20.f, 120.f)
            RectangleF(390.f, 0.f, 20.f, 560.f)
        ]
    }
]

// Hanghatás fájl betöltése
let hitSound = new SoundPlayer(@"hit.wav")
try hitSound.LoadAsync() with _ -> ()

// A többi kód változatlan marad, az ütésnél majd: hitSound.Play()


// Állapot változók
let mutable currentLevelIndex = 0
let mutable currentLevel = levels.[0]
let mutable ball = { Position = currentLevel.Start; Velocity = PointF(0.f, 0.f); Radius = 10.f }
let mutable aiming = false
let mutable mousePos = PointF(0.f, 0.f)
let mutable shotCounts = Array.zeroCreate levels.Length
let holeRadius = 8.f

// Mozgás segédfüggvények
let isBallInHole () =
    let dx = ball.Position.X - currentLevel.Hole.X
    let dy = ball.Position.Y - currentLevel.Hole.Y
    Math.Sqrt(float (dx * dx + dy * dy)) < float (ball.Radius + holeRadius |> float)

let intersectsObstacle (obs: Obstacle) =
    let ballRect = RectangleF(ball.Position.X - ball.Radius, ball.Position.Y - ball.Radius, ball.Radius * 2.f, ball.Radius * 2.f)
    obs.IntersectsWith(ballRect)

let isBallMoving () =
    abs ball.Velocity.X > 0.1f || abs ball.Velocity.Y > 0.1f

// Panel osztály
let panelWidth, panelHeight = 800, 600

let gamePanel =
    new Panel(Width = panelWidth, Height = panelHeight, BackColor = Color.Green, Dock = DockStyle.Fill)
do gamePanel.GetType().GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance ||| System.Reflection.BindingFlags.NonPublic)
    .SetValue(gamePanel, true, null)

gamePanel.Paint.Add(fun e ->
    let g = e.Graphics
    g.SmoothingMode <- Drawing2D.SmoothingMode.AntiAlias
    g.Clear(Color.Green)

    for obs in currentLevel.Obstacles do
        use b = new SolidBrush(Color.Brown)
        g.FillRectangle(b, obs)

    use holeBrush = new SolidBrush(Color.Black)
    g.FillEllipse(holeBrush, currentLevel.Hole.X - holeRadius, currentLevel.Hole.Y - holeRadius, holeRadius * 2.f, holeRadius * 2.f)

    if aiming then
        let dx = ball.Position.X - mousePos.X
        let dy = ball.Position.Y - mousePos.Y
        let magnitude = Math.Sqrt(float (dx * dx + dy * dy)) |> float32
        if magnitude > 5.f then
            let clampedMag = Math.Min(magnitude, 100.f)
            let dirX, dirY = dx / magnitude, dy / magnitude
            let endX, endY = ball.Position.X + dirX * clampedMag, ball.Position.Y + dirY * clampedMag
            let startPoint, endPoint = ball.Position, PointF(endX, endY)
            use gradientBrush = new Drawing2D.LinearGradientBrush(startPoint, endPoint, Color.Red, Color.Orange)
            let path = new Drawing2D.GraphicsPath()
            path.AddLine(startPoint, endPoint)

            let arrowSize = 10.f
            let angle = Math.Atan2(float endY - float startPoint.Y, float endX - float startPoint.X)
            let left = PointF(endX - arrowSize * float32(Math.Cos(angle - Math.PI / 6.0)), endY - arrowSize * float32(Math.Sin(angle - Math.PI / 6.0)))
            let right = PointF(endX - arrowSize * float32(Math.Cos(angle + Math.PI / 6.0)), endY - arrowSize * float32(Math.Sin(angle + Math.PI / 6.0)))
            path.AddPolygon([| endPoint; left; right |])
            g.FillPath(gradientBrush, path)

    use ballBrush = new SolidBrush(Color.White)
    g.FillEllipse(ballBrush, ball.Position.X - ball.Radius, ball.Position.Y - ball.Radius, ball.Radius * 2.f, ball.Radius * 2.f)
)

let form = new Form(Text = "2D Minigolf - FlickerFix", Width = panelWidth, Height = panelHeight)
form.Controls.Add(gamePanel)

let timer = new Timer(Interval = 16)
timer.Tick.Add(fun _ ->
    ball.Position <- PointF(ball.Position.X + ball.Velocity.X, ball.Position.Y + ball.Velocity.Y)
    ball.Velocity <- PointF(ball.Velocity.X * 0.98f, ball.Velocity.Y * 0.98f)

    if ball.Position.X - ball.Radius < 0.f || ball.Position.X + ball.Radius > float32 panelWidth then
        ball.Velocity <- PointF(-ball.Velocity.X, ball.Velocity.Y)
    if ball.Position.Y - ball.Radius < 0.f || ball.Position.Y + ball.Radius > float32 panelHeight then
        ball.Velocity <- PointF(ball.Velocity.X, -ball.Velocity.Y)

    for obs in currentLevel.Obstacles do
        if intersectsObstacle obs then
            ball.Velocity <- PointF(-ball.Velocity.X, -ball.Velocity.Y)

    if isBallInHole () then
        currentLevelIndex <- currentLevelIndex + 1
        if currentLevelIndex < levels.Length then
            currentLevel <- levels.[currentLevelIndex]
            ball <- { Position = currentLevel.Start; Velocity = PointF(0.f, 0.f); Radius = 10.f }
        else
            timer.Stop()
            let msg = [for i in 0 .. levels.Length - 1 -> sprintf "%s: %d ütés" levels.[i].Name shotCounts.[i]] |> String.concat "\n"
            MessageBox.Show("Gratulálok! Teljesítetted az összes pályát! 🏆\n\n" + msg) |> ignore
            form.Close()

    gamePanel.Invalidate()
)

gamePanel.MouseMove.Add(fun e -> mousePos <- PointF(float32 e.X, float32 e.Y))
gamePanel.MouseDown.Add(fun e -> if e.Button = MouseButtons.Left && not (isBallMoving()) then aiming <- true)
gamePanel.MouseUp.Add(fun e ->
    if e.Button = MouseButtons.Left && aiming && not (isBallMoving()) then
        aiming <- false
        let dx = ball.Position.X - float32 e.X
        let dy = ball.Position.Y - float32 e.Y
        let magnitude = Math.Sqrt(float (dx * dx + dy * dy)) |> float32
        if magnitude > 5.f then
            let clampedMag = Math.Min(magnitude, 100.f)
            let direction = PointF(dx / magnitude, dy / magnitude)
            let strength = clampedMag / 10.f
            ball.Velocity <- PointF(direction.X * strength, direction.Y * strength)
            shotCounts.[currentLevelIndex] <- shotCounts.[currentLevelIndex] + 1
)

[<EntryPoint>]
let main _ =
    timer.Start()
    Application.Run(form)
    0