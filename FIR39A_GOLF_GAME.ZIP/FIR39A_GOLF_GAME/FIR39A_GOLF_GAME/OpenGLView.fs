﻿namespace IJ45HA_MIDI_Visualizer

open System
open OpenTK
open OpenTK.Graphics
open OpenTK.Graphics.OpenGL
open OpenTK.Input
open IJ45HA_MIDI_Visualizer.Game

type GameWindow3D() =
    inherit GameWindow(800, 600, GraphicsMode.Default, "MiniGolf 3D", GameWindowFlags.Default, DisplayDevice.Default)

    override this.OnLoad(e) =
        base.OnLoad(e)
        GL.ClearColor(0.2f, 0.3f, 0.3f, 1.0f)
        GL.Enable(EnableCap.DepthTest)

    override this.OnRenderFrame(e) =
        base.OnRenderFrame(e)

        GL.Clear(ClearBufferMask.ColorBufferBit ||| ClearBufferMask.DepthBufferBit)

        // ✅ Zöld pálya (sík)
        GL.Begin(PrimitiveType.Quads)
        GL.Color3(0.1f, 0.5f, 0.1f)
        GL.Vertex3(-2.0f, 0.0f, -2.0f)
        GL.Vertex3( 2.0f, 0.0f, -2.0f)
        GL.Vertex3( 2.0f, 0.0f,  2.0f)
        GL.Vertex3(-2.0f, 0.0f,  2.0f)
        GL.End()

        // ✅ Labda frissítése és kirajzolása
        updateBall()
        drawSphere ball.Position ball.Radius

        this.SwapBuffers()

module GameLauncher =
    let start3DGame () =
        use window = new GameWindow3D()
        window.Run()
