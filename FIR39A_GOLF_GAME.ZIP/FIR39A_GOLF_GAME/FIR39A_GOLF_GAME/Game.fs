﻿namespace IJ45HA_MIDI_Visualizer

open System
open OpenTK
open OpenTK.Graphics.OpenGL
open System


module Game =

    type Ball =
        {
            mutable Position: Vector3
            mutable Velocity: Vector3
            Radius: float32
        }

    let mutable ball =
        {
            Position = Vector3(0.0f, 0.1f, 0.0f)
            Velocity = Vector3.Zero
            Radius = 0.1f
        }

    let friction = 0.98f

    let updateBall () =
        ball.Position <- ball.Position + ball.Velocity
        ball.Velocity <- ball.Velocity * friction

        // Egyszerű falütközés
        if ball.Position.X < -1.9f || ball.Position.X > 1.9f then
            ball.Velocity <- Vector3(-ball.Velocity.X, ball.Velocity.Y, ball.Velocity.Z)
        if ball.Position.Z < -1.9f || ball.Position.Z > 1.9f then
            ball.Velocity <- Vector3(ball.Velocity.X, ball.Velocity.Y, -ball.Velocity.Z)

    let drawSphere (pos: Vector3) (radius: float32) =
        let segments = 32
        GL.Color3(1.0f, 1.0f, 0.0f)
        GL.Begin(PrimitiveType.TriangleFan)
        GL.Vertex3(pos.X, pos.Y, pos.Z)
        for i in 0 .. segments do
            let angle = float32 i / float32 segments * float32 Math.PI * 2.0f
            let x = pos.X + cos angle * radius
            let z = pos.Z + sin angle * radius
            let y = pos.Y
            GL.Vertex3(x, y, z)
        GL.End()
